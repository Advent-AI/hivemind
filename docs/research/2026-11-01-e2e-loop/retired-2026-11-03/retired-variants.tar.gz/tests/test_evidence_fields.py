"""Extraction v78 / poc-v98 (design-v78-fields.md, D269): each evidence item classifies itself first in three closed sets the schema defines
(party, news, scale), and code applies the standard's keep rule to that classification; an answer of an earlier version carries no fields and
is not judged by it; v77's request bytes are unchanged. Real ledger on a temporary path; a scripted model; the universe the pipeline reads."""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'src'))
from hivemind import config, extraction, model  # noqa: E402
from hivemind.views import store  # noqa: E402
from test_one_decider import snapshot_ledger  # noqa: E402
from test_placement import ITEM, KRESS, PLATFORM, TEXT, UNI  # noqa: E402

V98 = config.load(os.path.join(ROOT, 'poc', 'config', 'poc-v98.json'))
V97 = config.load(os.path.join(ROOT, 'poc', 'config', 'poc-v97.json'))


def test_v78_schema_asks_the_three_classes_first_with_the_standards_values_and_v77_does_not(tmp_path):
    conn = snapshot_ledger(tmp_path)
    shown = extraction.shown_views(conn, V98, ITEM, ['NVDA'])
    _, _, user, schema = extraction.request_for(V98, ITEM, TEXT, shown, UNI)
    fields = schema['properties']['evidence']['items']['properties']
    assert list(fields)[:3] == ['party', 'news', 'scale'] and schema['properties']['evidence']['items']['required'][:3] == ['party', 'news', 'scale']
    assert fields['party']['enum'] == ['company', 'customer', 'supplier', 'competitor', 'partner', 'regulator', 'analyst_or_outlet', 'unrelated']
    assert fields['news']['enum'][:4] == ['new_step', 'new_figure', 'forecast_or_plan', 'policy_step'] and fields['scale']['enum'] == ['size', 'date', 'name', 'none']
    assert 'the main supplier said its capacity will double by 2027' in fields['party']['description']   # the standard's own example, another industry
    assert not user.rstrip().endswith('Return only the items you keep.')                                 # no end-of-request check from v78
    assert '- Go through the item from its first paragraph to its last. For each statement, fill the three fields' in extraction._read('role-v78.txt')
    _, _, user77, schema77 = extraction.request_for(V97, ITEM, TEXT, extraction.shown_views(conn, V97, ITEM, ['NVDA']), UNI)
    assert 'party' not in schema77['properties']['evidence']['items']['properties'] and user77.rstrip().endswith('Return only the items you keep.')


def test_the_standards_rule_drops_by_the_statements_own_classes_and_keeps_the_rest():
    company_step = {'party': 'company', 'news': 'new_step', 'scale': 'name'}
    assert extraction.evidence_rule(company_step) is None
    assert extraction.evidence_rule({'party': 'analyst_or_outlet', 'news': 'judgement', 'scale': 'none'}) is None     # a named party's claim needs no size (D240)
    assert extraction.evidence_rule({'party': 'supplier', 'news': 'new_step', 'scale': 'size'}) is None
    assert extraction.evidence_rule({'party': 'regulator', 'news': 'policy_step', 'scale': 'none'}) is None            # an undated refusal is a step
    assert extraction.evidence_rule({'party': 'company', 'news': 'retelling', 'scale': 'size'}) == 'not evidence: retelling'
    assert extraction.evidence_rule({'party': 'company', 'news': 'background', 'scale': 'none'}) == 'not evidence: background'
    assert extraction.evidence_rule({'party': 'partner', 'news': 'new_step', 'scale': 'none'}) == 'not evidence: related party without a size, date or name'
    assert extraction.evidence_rule({'party': 'unrelated', 'news': 'new_figure', 'scale': 'size'}) == 'not evidence: unrelated party'
    assert extraction.evidence_rule(dict(PLATFORM)) is None                                                            # an earlier version's answer: not judged


def test_v78_sift_drops_by_the_rule_with_its_reason_and_files_the_rest(tmp_path):
    conn = snapshot_ledger(tmp_path)

    def transport(provider, request):
        data = {'candidates': [], 'new_groups': [],
                'evidence': [dict(PLATFORM, party='company', news='new_step', scale='size', links=['v1']),
                             dict(KRESS, party='company', news='retelling', scale='none', links=['v2']),
                             dict(KRESS, id='e3', quote='Nvidia shares climbed 3.7 per cent on July 8.', party='company', news='market_move', scale='size', links=['v1'])]}
        return {'choices': [{'message': {'content': json.dumps(data)}}]}

    shown = extraction.shown_views(conn, V98, ITEM, ['NVDA'])
    handover = extraction.extract(archive=model.Archive(str(tmp_path / 'archive.sqlite')), cfg=V98, item=ITEM, text=TEXT, shown_views=shown, universe=UNI, transport=transport)
    assert [(e['id'], e['links'], e['party'], e['news']) for e in handover.evidence] == [('e1', ['v1'], 'company', 'new_step')]
    assert sorted(handover.dropped) == [('e2', 'not evidence: retelling'), ('e3', 'not evidence: market_move')]


def test_v79_asks_the_newness_question_first_and_the_rule_keeps_only_new_statements_of_kept_kinds(tmp_path):
    """v79 (design-v78-fields.md §5): the standard's first question is its own field before the shape; a known statement, a product comparison or
    a market move is not evidence; a new statement of a kept kind by the company or a named party is; v78 answers keep their own rule."""
    v99 = config.load(os.path.join(ROOT, 'poc', 'config', 'poc-v99.json'))
    conn = snapshot_ledger(tmp_path)
    _, _, user, schema = extraction.request_for(v99, ITEM, TEXT, extraction.shown_views(conn, v99, ITEM, ['NVDA']), UNI)
    fields = schema['properties']['evidence']['items']['properties']
    assert list(fields)[:4] == ['new', 'kind', 'party', 'scale'] and fields['new']['enum'] == ['new', 'known']
    assert 'two airlines fly the planemaker' in fields['new']['description'] and 'ten times cheaper per run' in fields['kind']['description']
    assert 'Write every statement that has one of the kinds the schema defines, whether you judge it new or known' in extraction._read('role-v79.txt')
    assert extraction.evidence_rule({'new': 'known', 'kind': 'step', 'party': 'company', 'scale': 'name'}) == 'not evidence: known'
    assert extraction.evidence_rule({'new': 'new', 'kind': 'product_comparison_or_detail', 'party': 'partner', 'scale': 'size'}) == 'not evidence: product_comparison_or_detail'
    assert extraction.evidence_rule({'new': 'new', 'kind': 'market_move', 'party': 'company', 'scale': 'size'}) == 'not evidence: market_move'
    assert extraction.evidence_rule({'new': 'new', 'kind': 'step', 'party': 'partner', 'scale': 'none'}) == 'not evidence: related party without a size, date or name'
    assert extraction.evidence_rule({'new': 'new', 'kind': 'judgement', 'party': 'analyst_or_outlet', 'scale': 'none'}) is None
    assert extraction.evidence_rule({'new': 'new', 'kind': 'policy_step', 'party': 'regulator', 'scale': 'none'}) is None
    assert extraction.evidence_rule({'party': 'company', 'news': 'retelling', 'scale': 'size'}) == 'not evidence: retelling'       # a v78 answer


def test_v80_adds_view_as_a_kind_that_is_not_evidence_and_keeps_v79_answers_on_their_rule(tmp_path):
    """v80 (design-v78-fields.md §8): the kind set gains "view" (standard 5.3: a general view, framing or characterization with no new fact), not
    kept; a v79 answer, which has no such value, is judged as before."""
    v100 = config.load(os.path.join(ROOT, 'poc', 'config', 'poc-v100.json'))
    conn = snapshot_ledger(tmp_path)
    _, _, user, schema = extraction.request_for(v100, ITEM, TEXT, extraction.shown_views(conn, v100, ITEM, ['NVDA']), UNI)
    fields = schema['properties']['evidence']['items']['properties']
    assert list(fields)[:4] == ['new', 'kind', 'party', 'scale'] and 'view' in fields['kind']['enum']
    assert 'even when the item credits an earlier report for it' in fields['new']['description']
    assert 'a view with no new fact or figure' in extraction._read('role-v80.txt')
    assert extraction.evidence_rule({'new': 'new', 'kind': 'view', 'party': 'analyst_or_outlet', 'scale': 'none'}) == 'not evidence: view'
    assert extraction.evidence_rule({'new': 'new', 'kind': 'judgement', 'party': 'analyst_or_outlet', 'scale': 'none'}) is None
